import React, { useState, useCallback, useEffect, useRef } from 'react'
import MapCanvas from './components/MapCanvas'
import DrawingPanel from './components/DrawingPanel'
import StatusBar from './components/StatusBar'
import { useGeolocation } from './hooks/useGeolocation'
import { useDrawingTrack } from './hooks/useDrawingTrack'
import { saveLayers, loadLayers, clearLayers } from './utils/storage'

export default function App() {
  const [layers, setLayers] = useState(() => loadLayers())
  const [isRecording, setIsRecording] = useState(false)
  const { startSession, addPoint, endSession, isActive } = useDrawingTrack()
  const sessionPendingRef = useRef(null) // pending stamp session

  // Save layers whenever they change
  useEffect(() => { saveLayers(layers) }, [layers])

  // Called every time GPS position updates
  const handlePosition = useCallback((pos) => {
    if (!isActive()) return
    const session = addPoint(pos)
    if (!session) return

    if (session.mode === 'track') {
      // Live update the last layer while tracking
      setLayers(prev => {
        const last = prev[prev.length - 1]
        if (last && last.id === session._id) {
          return [...prev.slice(0, -1), { ...last, points: [...session.points] }]
        }
        return prev
      })
    }
  }, [isActive, addPoint])

  const [tracking, setTracking] = useState(false)
  const { position, error, loading, getOnce } = useGeolocation({ tracking, onPosition: handlePosition })

  // Start GPS as soon as app loads
  useEffect(() => {
    getOnce()
    // eslint-disable-next-line
  }, [])

  const handleStart = useCallback(({ mode, content, color, fontSize }) => {
    if (mode === 'stamp') {
      // Place stamp at current position immediately
      if (!position) { alert('位置情報を取得できていません。しばらく待ってください。'); return }
      const newLayer = {
        id: Date.now().toString(),
        mode: 'stamp',
        content, color, fontSize,
        lat: position.lat,
        lng: position.lng,
      }
      setLayers(prev => [...prev, newLayer])
    } else {
      // Start tracking mode
      const id = Date.now().toString()
      const newLayer = {
        id, mode: 'track', content, color, fontSize, points: [],
      }
      startSession({ mode, content, color, fontSize })
      newLayer._id = id
      // We'll track by ref
      sessionPendingRef.current = id
      setLayers(prev => [...prev, newLayer])
      setTracking(true)
      setIsRecording(true)
    }
  }, [position, startSession])

  const handleStop = useCallback(() => {
    setTracking(false)
    setIsRecording(false)
    endSession()
  }, [endSession])

  const handleClear = useCallback(() => {
    if (window.confirm('全ての描画を削除しますか？')) {
      clearLayers()
      setLayers([])
      if (isRecording) handleStop()
    }
  }, [isRecording, handleStop])

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh' }}>
      {/* Pulse animation */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(0.8); }
        }
      `}</style>

      <MapCanvas position={position} layers={layers} />

      <DrawingPanel
        onStart={handleStart}
        onStop={handleStop}
        isRecording={isRecording}
        onClear={handleClear}
      />

      <StatusBar
        position={position}
        error={error}
        loading={loading}
        layerCount={layers.length}
      />
    </div>
  )
}
