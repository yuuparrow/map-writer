import React, { useEffect, useRef } from 'react'
import { MapContainer, TileLayer, useMap, Marker, Polyline, Tooltip } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
})

function createTextIcon(content, color, fontSize) {
  const isEmoji = /\p{Emoji}/u.test(content)
  const html = `
    <div style="
      font-size: ${isEmoji ? fontSize + 8 : fontSize}px;
      color: ${color};
      white-space: nowrap;
      text-shadow: 0 0 8px ${color}88, 1px 1px 0 #000, -1px -1px 0 #000;
      font-family: 'Space Mono', monospace;
      font-weight: 700;
      pointer-events: auto;
      user-select: none;
      transform: translateX(-50%);
      display: inline-block;
    ">${content}</div>
  `
  return L.divIcon({ html, className: '', iconAnchor: [0, 0] })
}

// Fly to position when it changes
function FlyToPosition({ position }) {
  const map = useMap()
  const initialRef = useRef(false)
  useEffect(() => {
    if (!position) return
    if (!initialRef.current) {
      map.setView([position.lat, position.lng], 16)
      initialRef.current = true
    }
  }, [position, map])
  return null
}

// Current location marker
function LocationMarker({ position }) {
  if (!position) return null
  const icon = L.divIcon({
    html: `
      <div style="
        width:16px; height:16px; border-radius:50%;
        background:#0066ff; border:3px solid white;
        box-shadow:0 0 0 4px rgba(0,102,255,0.25), 0 2px 8px rgba(0,0,0,0.5);
        position:relative;
      "></div>
    `,
    className: '',
    iconAnchor: [8, 8],
  })
  return <Marker position={[position.lat, position.lng]} icon={icon} />
}

export default function MapCanvas({ position, layers, onMapReady }) {
  const defaultCenter = [35.6812, 139.7671] // Tokyo

  return (
    <MapContainer
      center={defaultCenter}
      zoom={13}
      style={{ width: '100%', height: '100%' }}
      zoomControl={true}
      ref={onMapReady}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        maxZoom={19}
      />

      <FlyToPosition position={position} />
      <LocationMarker position={position} />

      {layers.map((layer) => {
        if (layer.mode === 'stamp') {
          return (
            <Marker
              key={layer.id}
              position={[layer.lat, layer.lng]}
              icon={createTextIcon(layer.content, layer.color, layer.fontSize)}
            />
          )
        }
        if (layer.mode === 'track' && layer.points?.length > 1) {
          const latlngs = layer.points.map(p => [p.lat, p.lng])
          // Render each segment as a letter/emoji repeat along the line
          return (
            <React.Fragment key={layer.id}>
              <Polyline
                positions={latlngs}
                pathOptions={{
                  color: layer.color,
                  weight: layer.fontSize / 6,
                  opacity: 0.85,
                  lineCap: 'round',
                  lineJoin: 'round',
                }}
              />
              {/* Place content label at midpoint */}
              {(() => {
                const mid = latlngs[Math.floor(latlngs.length / 2)]
                const icon = createTextIcon(layer.content, layer.color, layer.fontSize)
                return <Marker key={layer.id + '_mid'} position={mid} icon={icon} />
              })()}
            </React.Fragment>
          )
        }
        return null
      })}
    </MapContainer>
  )
}
